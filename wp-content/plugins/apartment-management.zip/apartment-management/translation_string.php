<th><?php esc_html_e('Unit Members','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Occupied From Date','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Occupied To Date','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Are you sure want to delete this record?','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Add Building Category','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Add Unit Category','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Unit Category Name','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Add Designation','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Designation Name','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Add Staff Category','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Staff Category Name','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Payment Method','apartment_mgt'); ?></th> 
<th><?php esc_html_e('| Bill To.','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Notes','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Total Paid Amount :','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Entry','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Subtotal :','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Discount Amount :','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Discount Amount :','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Tax Amount :','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Due Amount :','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Paid Amount :','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Grand Total :','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Print','apartment_mgt'); ?></th> 
<th><?php esc_html_e('PDF','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Billing Period','apartment_mgt'); ?></th> 
<th><?php esc_html_e('From (','apartment_mgt'); ?></th> 
<th><?php esc_html_e('To (','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Complaint Details','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Nature:','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Type:','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Category:','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Created By:','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Status:','apartment_mgt'); ?></th> 
<th><?php esc_html_e('GATE: ','apartment_mgt'); ?></th> 
<th><?php esc_html_e('COMPOUND: ','apartment_mgt'); ?></th> 
<th><?php esc_html_e('UNIT CATEGORY: ','apartment_mgt'); ?></th> 
<th><?php esc_html_e('UNIT NUMBER: ','apartment_mgt'); ?></th> 
<th><?php esc_html_e('REASON FOR VISIT: ','apartment_mgt'); ?></th> 
<th><?php esc_html_e('VISIT DATE: ','apartment_mgt'); ?></th> 
<th><?php esc_html_e('VISIT TIME: ','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Checkout','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Gate','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Checkout','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Unit Documents','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Document Submitted Date','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Document Title','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Select Profile Picture','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Member','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Accountant','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Staff member','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Gatekeeper','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Administrator','apartment_mgt'); ?></th> 
<th><?php esc_html_e('From: ','apartment_mgt'); ?></th> 
<th><?php esc_html_e('To: ','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Notice Details','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Notice Title:','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Valid Date:','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Notice Type:','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Add visit Reason','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Reason Name','apartment_mgt'); ?></th> 
<th><?php esc_html_e('owner family','apartment_mgt'); ?></th> 
<th><?php esc_html_e('No Records Found !','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Event Detail','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Add Category','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Category Name','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Add Activity For Facility Booking','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Add Activity','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Payment By','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Cash','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Cheque','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Bank Transfer','apartment_mgt'); ?></th>
<th><?php esc_html_e('Add Payment','apartment_mgt'); ?></th>
<th><?php esc_html_e('Add Charges Types','apartment_mgt'); ?></th>
<th><?php esc_html_e('Charges Name','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Add Expense Types','apartment_mgt'); ?></th>
<th><?php esc_html_e('Types Name','apartment_mgt'); ?></th>
<th><?php esc_html_e('Add Types','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Add Assets Category','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Add Inventory Unit Category','apartment_mgt'); ?></th>
<th><?php esc_html_e('Member Registration','apartment_mgt'); ?></th>
<th><?php esc_html_e('Your registration is complete. Your account will active after admin will approve.','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Select all','apartment_mgt'); ?></th> 
<th><?php esc_html_e('From','apartment_mgt'); ?></th> 
<th><?php esc_html_e('To','apartment_mgt'); ?></th> 
<th><?php esc_html_e('A/C Holder Name ','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Account No ','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Required form field is missing','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Username too short. At least 4 characters is required','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Sorry, that username already exists!','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Sorry, the username you entered is not valid','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Email is not valid','apartment_mgt'); ?></th> 
<th><?php esc_html_e('Email Already in use','apartment_mgt'); ?></th> 
<th><?php esc_html_e('tenant','apartment_mgt'); ?></th>
<th><?php esc_html_e('Only CSV file are allow.','apartment_mgt'); ?></th>
<th><?php esc_html_e('INVOICE','apartment_mgt'); ?></th>
<th><?php esc_html_e('Invoice Payment Receipt','apartment_mgt'); ?></th>