<html>
	<h1>Your browser javascript not enabled! Please first enable browser javascript.</h1>
</html>
<?php
die;
?>