<div class="wrap">
    <div class="container">
        <?php maisonco_render_footer(); ?>
    </div>
</div>